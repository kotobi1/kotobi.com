import React from 'react';
import { Review } from '../../types';
import StarRating from '../Books/StarRating';
import { useLanguage } from '../../contexts/LanguageContext';

interface ReviewCardProps {
  review: Review;
}

const ReviewCard: React.FC<ReviewCardProps> = ({ review }) => {
  const { t } = useLanguage();
  
  // Format date
  const formattedDate = new Date(review.date).toLocaleDateString();
  
  return (
    <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm mb-4">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center">
          <div className="h-10 w-10 rounded-full bg-amber-200 dark:bg-blue-900 flex items-center justify-center text-amber-800 dark:text-blue-200 font-semibold">
            {review.userName.charAt(0)}
          </div>
          <div className="ml-3 rtl:mr-3 rtl:ml-0">
            <p className="font-semibold text-gray-900 dark:text-white">{review.userName}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">{formattedDate}</p>
          </div>
        </div>
        <StarRating initialRating={review.rating} editable={false} size="sm" />
      </div>
      
      <p className="text-gray-700 dark:text-gray-300">{review.text}</p>
    </div>
  );
};

export default ReviewCard;