import React, { useState } from 'react';
import StarRating from '../Books/StarRating';
import { useLanguage } from '../../contexts/LanguageContext';

interface ReviewFormProps {
  onSubmit: (rating: number, text: string) => void;
}

const ReviewForm: React.FC<ReviewFormProps> = ({ onSubmit }) => {
  const { t } = useLanguage();
  const [rating, setRating] = useState(0);
  const [reviewText, setReviewText] = useState('');
  const [error, setError] = useState<string | null>(null);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (rating === 0) {
      setError('Please select a rating');
      return;
    }
    
    if (reviewText.trim().length < 3) {
      setError('Please write a review with at least 3 characters');
      return;
    }
    
    // Submit review
    onSubmit(rating, reviewText);
    
    // Reset form
    setRating(0);
    setReviewText('');
    setError(null);
  };
  
  return (
    <div className="bg-amber-50 dark:bg-gray-900 p-4 rounded-lg border border-amber-200 dark:border-blue-800 mb-8">
      <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">
        {t('book.writeReview')}
      </h3>
      
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            {t('book.rating')}
          </label>
          <StarRating 
            initialRating={rating} 
            editable={true} 
            onRatingChange={setRating}
            size="lg"
          />
        </div>
        
        <div className="mb-4">
          <label 
            htmlFor="reviewText" 
            className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
          >
            {t('book.reviews')}
          </label>
          <textarea
            id="reviewText"
            value={reviewText}
            onChange={(e) => setReviewText(e.target.value)}
            className="w-full px-3 py-2 text-gray-700 dark:text-white border rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 dark:focus:ring-blue-500 bg-white dark:bg-gray-800 dark:border-gray-700"
            rows={4}
          />
        </div>
        
        {error && (
          <div className="mb-4 text-red-500 text-sm">
            {error}
          </div>
        )}
        
        <button 
          type="submit"
          className="px-4 py-2 bg-amber-600 dark:bg-blue-700 text-white rounded-lg hover:bg-amber-700 dark:hover:bg-blue-800 transition-colors focus:outline-none focus:ring-2 focus:ring-amber-500 dark:focus:ring-blue-500 focus:ring-offset-2"
        >
          {t('book.submitReview')}
        </button>
      </form>
    </div>
  );
};

export default ReviewForm;