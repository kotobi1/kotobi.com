import React from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import { useLanguage } from '../../contexts/LanguageContext';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { dir } = useLanguage();
  
  return (
    <div className={`min-h-screen flex flex-col bg-amber-50 dark:bg-gray-900 ${dir === 'rtl' ? 'font-arabic' : 'font-english'}`}>
      <Navbar />
      <main className="flex-grow container mx-auto px-4 py-8">
        {children}
      </main>
      <Footer />
    </div>
  );
};

export default Layout;