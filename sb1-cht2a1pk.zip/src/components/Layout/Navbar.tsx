import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { useTheme } from '../../contexts/ThemeContext';
import { Book, Search, Menu, X, User, LogOut, Moon, Sun } from 'lucide-react';

const Navbar: React.FC = () => {
  const { user, logout } = useAuth();
  const { t, language, setLanguage } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
      setSearchQuery('');
      setIsMenuOpen(false);
    }
  };

  const toggleMenu = () => {
    setIsMenuOpen(prev => !prev);
  };

  return (
    <nav className="bg-amber-600 dark:bg-blue-900 text-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* Logo and brand */}
          <Link to="/" className="flex items-center space-x-2 rtl:space-x-reverse">
            <Book className="h-8 w-8" />
            <span className="text-xl font-bold">BookVerse</span>
          </Link>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center space-x-4 rtl:space-x-reverse">
            <div className="relative">
              <form onSubmit={handleSearch} className="flex">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={t('search.placeholder')}
                  className="w-64 px-4 py-1 rounded-l-md text-gray-800 focus:outline-none"
                />
                <button 
                  type="submit"
                  className="bg-amber-700 dark:bg-blue-800 px-4 py-1 rounded-r-md hover:bg-amber-800 dark:hover:bg-blue-700 transition"
                >
                  <Search className="h-5 w-5" />
                </button>
              </form>
            </div>
            
            <Link to="/" className="hover:text-amber-200 dark:hover:text-blue-200 transition">
              {t('nav.home')}
            </Link>
            <Link to="/my-books" className="hover:text-amber-200 dark:hover:text-blue-200 transition">
              {t('nav.myBooks')}
            </Link>
            
            {/* Settings dropdown */}
            <div className="relative group">
              <button className="flex items-center hover:text-amber-200 dark:hover:text-blue-200 transition">
                {t('settings')}
              </button>
              <div className="absolute right-0 rtl:left-0 rtl:right-auto mt-2 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg py-1 z-10 hidden group-hover:block">
                {/* Theme toggle */}
                <button 
                  onClick={toggleTheme}
                  className="w-full text-left rtl:text-right px-4 py-2 text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center"
                >
                  {theme === 'dark' ? <Sun className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0" /> : <Moon className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0" />}
                  {theme === 'dark' ? t('light') : t('dark')}
                </button>
                
                {/* Language toggle */}
                <button 
                  onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')}
                  className="w-full text-left rtl:text-right px-4 py-2 text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  {language === 'en' ? 'العربية' : 'English'}
                </button>
              </div>
            </div>
            
            {user ? (
              <div className="relative group">
                <button className="flex items-center space-x-2 rtl:space-x-reverse hover:text-amber-200 dark:hover:text-blue-200 transition">
                  <img 
                    src={user.avatar || 'https://images.pexels.com/photos/1040881/pexels-photo-1040881.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'} 
                    alt={user.fullName}
                    className="h-8 w-8 rounded-full object-cover"
                  />
                  <span>{user.fullName}</span>
                </button>
                <div className="absolute right-0 rtl:left-0 rtl:right-auto mt-2 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg py-1 z-10 hidden group-hover:block">
                  <button 
                    onClick={logout}
                    className="w-full text-left rtl:text-right px-4 py-2 text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center"
                  >
                    <LogOut className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0" />
                    {t('auth.logout')}
                  </button>
                </div>
              </div>
            ) : (
              <Link 
                to="/login" 
                className="px-4 py-2 rounded-md bg-amber-700 dark:bg-blue-800 hover:bg-amber-800 dark:hover:bg-blue-700 transition"
              >
                {t('auth.login')}
              </Link>
            )}
          </div>

          {/* Mobile menu button */}
          <button 
            onClick={toggleMenu}
            className="md:hidden text-white focus:outline-none"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-amber-600 dark:bg-blue-900 pb-4 px-4">
          <form onSubmit={handleSearch} className="flex mb-4">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t('search.placeholder')}
              className="flex-grow px-4 py-2 rounded-l-md text-gray-800 focus:outline-none"
            />
            <button 
              type="submit"
              className="bg-amber-700 dark:bg-blue-800 px-4 py-2 rounded-r-md hover:bg-amber-800 dark:hover:bg-blue-700 transition"
            >
              <Search className="h-5 w-5" />
            </button>
          </form>
          
          <div className="flex flex-col space-y-3">
            <Link 
              to="/" 
              className="text-white hover:text-amber-200 dark:hover:text-blue-200 transition"
              onClick={() => setIsMenuOpen(false)}
            >
              {t('nav.home')}
            </Link>
            <Link 
              to="/my-books" 
              className="text-white hover:text-amber-200 dark:hover:text-blue-200 transition"
              onClick={() => setIsMenuOpen(false)}
            >
              {t('nav.myBooks')}
            </Link>
            
            {/* Theme toggle */}
            <button 
              onClick={toggleTheme}
              className="text-white hover:text-amber-200 dark:hover:text-blue-200 transition flex items-center"
            >
              {theme === 'dark' ? <Sun className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0" /> : <Moon className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0" />}
              {theme === 'dark' ? t('light') : t('dark')}
            </button>
            
            {/* Language toggle */}
            <button 
              onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')}
              className="text-white hover:text-amber-200 dark:hover:text-blue-200 transition"
            >
              {language === 'en' ? 'العربية' : 'English'}
            </button>
            
            {user ? (
              <>
                <div className="flex items-center space-x-2 rtl:space-x-reverse">
                  <img 
                    src={user.avatar || 'https://images.pexels.com/photos/1040881/pexels-photo-1040881.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'} 
                    alt={user.fullName}
                    className="h-8 w-8 rounded-full object-cover"
                  />
                  <span>{user.fullName}</span>
                </div>
                <button 
                  onClick={() => {
                    logout();
                    setIsMenuOpen(false);
                  }}
                  className="text-white hover:text-amber-200 dark:hover:text-blue-200 transition flex items-center"
                >
                  <LogOut className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0" />
                  {t('auth.logout')}
                </button>
              </>
            ) : (
              <Link 
                to="/login" 
                className="px-4 py-2 text-center rounded-md bg-amber-700 dark:bg-blue-800 hover:bg-amber-800 dark:hover:bg-blue-700 transition"
                onClick={() => setIsMenuOpen(false)}
              >
                {t('auth.login')}
              </Link>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;