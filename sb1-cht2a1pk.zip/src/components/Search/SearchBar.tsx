import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';

interface SearchBarProps {
  onSearch: (query: string, category?: string) => void;
  initialQuery?: string;
}

const SearchBar: React.FC<SearchBarProps> = ({ onSearch, initialQuery = '' }) => {
  const { t } = useLanguage();
  const [query, setQuery] = useState(initialQuery);
  const [category, setCategory] = useState<string>('');
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch(query, category || undefined);
    }
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md mb-8">
      <form onSubmit={handleSubmit} className="flex flex-col md:flex-row gap-4">
        <div className="flex-grow relative">
          <div className="absolute inset-y-0 left-0 rtl:right-0 rtl:left-auto flex items-center pl-3 rtl:pr-3 rtl:pl-0 pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t('search.placeholder')}
            className="w-full pl-10 rtl:pr-10 rtl:pl-3 py-2 text-gray-700 dark:text-white border rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 dark:focus:ring-blue-500 bg-white dark:bg-gray-800 dark:border-gray-700"
          />
        </div>
        
        <div className="w-full md:w-52">
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full py-2 px-3 text-gray-700 dark:text-white border rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 dark:focus:ring-blue-500 bg-white dark:bg-gray-800 dark:border-gray-700"
          >
            <option value="">{t('nav.categories')}</option>
            <option value="Fiction">{t('category.fiction')}</option>
            <option value="Science">{t('category.science')}</option>
            <option value="History">{t('category.history')}</option>
            <option value="Biography">{t('category.biography')}</option>
            <option value="Science Fiction">{t('category.scifi')}</option>
            <option value="Classic Literature">{t('category.classic')}</option>
          </select>
        </div>
        
        <button 
          type="submit"
          className="px-4 py-2 bg-amber-600 dark:bg-blue-700 text-white rounded-lg hover:bg-amber-700 dark:hover:bg-blue-800 transition-colors focus:outline-none focus:ring-2 focus:ring-amber-500 dark:focus:ring-blue-500 focus:ring-offset-2"
        >
          {t('search.button')}
        </button>
      </form>
    </div>
  );
};

export default SearchBar;