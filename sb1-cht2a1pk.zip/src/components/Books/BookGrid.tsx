import React from 'react';
import BookCard from './BookCard';
import { Book } from '../../types';
import { useLanguage } from '../../contexts/LanguageContext';

interface BookGridProps {
  books: Book[];
  title?: string;
  emptyMessage?: string;
}

const BookGrid: React.FC<BookGridProps> = ({ 
  books, 
  title, 
  emptyMessage = 'No books available' 
}) => {
  const { t } = useLanguage();
  
  if (books.length === 0) {
    return (
      <div className="py-8 text-center">
        <p className="text-gray-600 dark:text-gray-300">{emptyMessage}</p>
      </div>
    );
  }
  
  return (
    <div className="my-8">
      {title && (
        <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">{title}</h2>
      )}
      
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
        {books.map(book => (
          <BookCard key={book.id} book={book} />
        ))}
      </div>
    </div>
  );
};

export default BookGrid;