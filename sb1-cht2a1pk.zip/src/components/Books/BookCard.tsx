import React from 'react';
import { Link } from 'react-router-dom';
import { Star } from 'lucide-react';
import { Book } from '../../types';
import { useLanguage } from '../../contexts/LanguageContext';

interface BookCardProps {
  book: Book;
}

const BookCard: React.FC<BookCardProps> = ({ book }) => {
  const { t } = useLanguage();
  
  return (
    <Link 
      to={`/book/${book.id}`}
      className="group bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 flex flex-col h-full"
    >
      <div className="relative h-64 overflow-hidden">
        <img 
          src={book.cover} 
          alt={book.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
          <div className="p-4 text-white">
            <p className="line-clamp-3 text-sm opacity-90">{book.summary}</p>
          </div>
        </div>
      </div>
      
      <div className="p-4 flex-grow flex flex-col">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-1 line-clamp-2">{book.title}</h3>
        <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">{book.author}</p>
        
        <div className="flex items-center mt-auto">
          <div className="flex items-center">
            <Star className="h-4 w-4 text-amber-500 fill-current" />
            <span className="ml-1 text-amber-600 dark:text-amber-400 font-medium">{book.rating.toFixed(1)}</span>
          </div>
          <span className="mx-2 text-gray-400">•</span>
          <span className="text-sm text-gray-600 dark:text-gray-400">{book.category}</span>
        </div>
      </div>
    </Link>
  );
};

export default BookCard;