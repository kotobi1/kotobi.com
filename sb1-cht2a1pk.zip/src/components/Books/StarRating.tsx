import React, { useState } from 'react';
import { Star } from 'lucide-react';

interface StarRatingProps {
  initialRating?: number;
  editable?: boolean;
  onRatingChange?: (rating: number) => void;
  size?: 'sm' | 'md' | 'lg';
}

const StarRating: React.FC<StarRatingProps> = ({ 
  initialRating = 0, 
  editable = false,
  onRatingChange,
  size = 'md'
}) => {
  const [rating, setRating] = useState(initialRating);
  const [hoverRating, setHoverRating] = useState(0);
  
  const sizes = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6',
    lg: 'w-8 h-8'
  };
  
  const handleClick = (selectedRating: number) => {
    if (!editable) return;
    
    setRating(selectedRating);
    if (onRatingChange) {
      onRatingChange(selectedRating);
    }
  };
  
  const handleMouseEnter = (hoveredRating: number) => {
    if (!editable) return;
    setHoverRating(hoveredRating);
  };
  
  const handleMouseLeave = () => {
    if (!editable) return;
    setHoverRating(0);
  };
  
  return (
    <div className="flex">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          className={`${editable ? 'cursor-pointer' : 'cursor-default'} focus:outline-none p-1`}
          onClick={() => handleClick(star)}
          onMouseEnter={() => handleMouseEnter(star)}
          onMouseLeave={handleMouseLeave}
          disabled={!editable}
          aria-label={`Rate ${star} out of 5 stars`}
        >
          <Star 
            className={`${sizes[size]} ${
              (hoverRating || rating) >= star
                ? 'text-amber-500 fill-current'
                : 'text-gray-300 dark:text-gray-600'
            } transition-colors duration-150`}
          />
        </button>
      ))}
    </div>
  );
};

export default StarRating;