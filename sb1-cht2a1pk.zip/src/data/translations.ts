import { Translations } from '../types';

export const translations: Translations = {
  en: {
    // Authentication
    'auth.login': 'Login',
    'auth.register': 'Register',
    'auth.logout': 'Logout',
    'auth.email': 'Email',
    'auth.password': 'Password',
    'auth.fullName': 'Full Name',
    'auth.loginWithGoogle': 'Login with Google',
    'auth.loginWithFacebook': 'Login with Facebook',
    'auth.noAccount': 'Don\'t have an account?',
    'auth.haveAccount': 'Already have an account?',
    'auth.createAccount': 'Create Account',
    
    // Navigation
    'nav.home': 'Home',
    'nav.myBooks': 'My Books',
    'nav.search': 'Search',
    'nav.categories': 'Categories',
    
    // Book related
    'book.author': 'Author',
    'book.rating': 'Rating',
    'book.pages': 'Pages',
    'book.published': 'Published',
    'book.language': 'Language',
    'book.isbn': 'ISBN',
    'book.addToMyBooks': 'Add to My Books',
    'book.removeFromMyBooks': 'Remove from My Books',
    'book.reviews': 'Reviews',
    'book.writeReview': 'Write a Review',
    'book.submitReview': 'Submit Review',
    'book.relatedBooks': 'Related Books',
    
    // Categories
    'category.fiction': 'Fiction',
    'category.science': 'Science',
    'category.history': 'History',
    'category.biography': 'Biography',
    'category.scifi': 'Science Fiction',
    'category.classic': 'Classic Literature',
    
    // Search
    'search.placeholder': 'Search by title, author or category...',
    'search.button': 'Search',
    'search.noResults': 'No results found',
    'search.results': 'Search Results',
    
    // My Books
    'myBooks.empty': 'You haven\'t added any books yet',
    'myBooks.start': 'Start exploring and add books to your collection',
    
    // General
    'loading': 'Loading...',
    'error': 'An error occurred',
    'settings': 'Settings',
    'language': 'Language',
    'theme': 'Theme',
    'light': 'Light',
    'dark': 'Dark'
  },
  ar: {
    // Authentication
    'auth.login': 'تسجيل الدخول',
    'auth.register': 'إنشاء حساب',
    'auth.logout': 'تسجيل الخروج',
    'auth.email': 'البريد الإلكتروني',
    'auth.password': 'كلمة المرور',
    'auth.fullName': 'الاسم الكامل',
    'auth.loginWithGoogle': 'تسجيل الدخول بواسطة Google',
    'auth.loginWithFacebook': 'تسجيل الدخول بواسطة Facebook',
    'auth.noAccount': 'ليس لديك حساب؟',
    'auth.haveAccount': 'لديك حساب بالفعل؟',
    'auth.createAccount': 'إنشاء حساب',
    
    // Navigation
    'nav.home': 'الرئيسية',
    'nav.myBooks': 'كتبي',
    'nav.search': 'البحث',
    'nav.categories': 'التصنيفات',
    
    // Book related
    'book.author': 'المؤلف',
    'book.rating': 'التقييم',
    'book.pages': 'عدد الصفحات',
    'book.published': 'تاريخ النشر',
    'book.language': 'اللغة',
    'book.isbn': 'الرقم الدولي',
    'book.addToMyBooks': 'إضافة إلى كتبي',
    'book.removeFromMyBooks': 'إزالة من كتبي',
    'book.reviews': 'المراجعات',
    'book.writeReview': 'اكتب مراجعة',
    'book.submitReview': 'إرسال المراجعة',
    'book.relatedBooks': 'كتب ذات صلة',
    
    // Categories
    'category.fiction': 'روايات',
    'category.science': 'علوم',
    'category.history': 'تاريخ',
    'category.biography': 'سيرة ذاتية',
    'category.scifi': 'خيال علمي',
    'category.classic': 'أدب كلاسيكي',
    
    // Search
    'search.placeholder': 'ابحث بالعنوان أو المؤلف أو التصنيف...',
    'search.button': 'بحث',
    'search.noResults': 'لم يتم العثور على نتائج',
    'search.results': 'نتائج البحث',
    
    // My Books
    'myBooks.empty': 'لم تقم بإضافة أي كتب بعد',
    'myBooks.start': 'ابدأ باستكشاف الكتب وأضفها إلى مجموعتك',
    
    // General
    'loading': 'جاري التحميل...',
    'error': 'حدث خطأ',
    'settings': 'الإعدادات',
    'language': 'اللغة',
    'theme': 'المظهر',
    'light': 'فاتح',
    'dark': 'داكن'
  }
};