import { Book } from '../types';

export const mockBooks: Book[] = [
  {
    id: '1',
    title: 'ألف ليلة وليلة',
    author: 'مجهول',
    cover: 'https://images.pexels.com/photos/3747139/pexels-photo-3747139.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    summary: 'مجموعة من القصص والحكايات الشعبية ذات الأصول الهندية والفارسية والعربية، تتمحور حول شهرزاد التي تروي حكايات للملك شهريار.',
    category: 'أدب كلاسيكي',
    rating: 4.7,
    reviews: [
      {
        id: '101',
        userId: '1001',
        userName: 'أحمد محمد',
        rating: 5,
        text: 'من أجمل الكتب التراثية التي قرأتها، مليئة بالحكمة والعبر.',
        date: '2023-10-15T14:22:33Z'
      },
      {
        id: '102',
        userId: '1002',
        userName: 'سارة علي',
        rating: 4,
        text: 'قصص متنوعة ومشوقة تنقلك إلى عوالم مختلفة من الخيال.',
        date: '2023-09-20T09:15:07Z'
      }
    ],
    language: 'العربية',
    pages: 872,
    publishDate: '1000-01-01',
    isbn: '9789776171299'
  },
  {
    id: '2',
    title: 'The Alchemist',
    author: 'Paulo Coelho',
    cover: 'https://images.pexels.com/photos/6373291/pexels-photo-6373291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    summary: 'A magical story of Santiago, an Andalusian shepherd boy who yearns to travel in search of a worldly treasure.',
    category: 'Fiction',
    rating: 4.5,
    reviews: [
      {
        id: '201',
        userId: '2001',
        userName: 'John Smith',
        rating: 5,
        text: 'A life-changing book that makes you reflect on your own personal journey.',
        date: '2023-11-05T16:40:23Z'
      },
      {
        id: '202',
        userId: '2002',
        userName: 'Emily Johnson',
        rating: 4,
        text: 'Beautiful narrative with deep philosophical undertones.',
        date: '2023-10-12T11:34:56Z'
      }
    ],
    language: 'English',
    pages: 163,
    publishDate: '1988-01-01',
    isbn: '9780061122415'
  },
  {
    id: '3',
    title: 'العبقريات',
    author: 'عباس محمود العقاد',
    cover: 'https://images.pexels.com/photos/5769387/pexels-photo-5769387.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    summary: 'سلسلة كتب تتناول سير العظماء والعباقرة في الإسلام، قام بكتابتها الأديب المصري عباس محمود العقاد.',
    category: 'سيرة ذاتية',
    rating: 4.8,
    reviews: [
      {
        id: '301',
        userId: '3001',
        userName: 'محمد أحمد',
        rating: 5,
        text: 'كتاب رائع يقدم تحليلاً عميقاً لشخصيات إسلامية بارزة بأسلوب أدبي راقٍ.',
        date: '2023-08-18T13:25:11Z'
      }
    ],
    language: 'العربية',
    pages: 420,
    publishDate: '1942-01-01',
    isbn: '9789777950121'
  },
  {
    id: '4',
    title: 'Sapiens: A Brief History of Humankind',
    author: 'Yuval Noah Harari',
    cover: 'https://images.pexels.com/photos/6147018/pexels-photo-6147018.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    summary: 'A book that explores the history of the human species from the evolution of archaic human species to the 21st century.',
    category: 'Science',
    rating: 4.6,
    reviews: [
      {
        id: '401',
        userId: '4001',
        userName: 'Robert Williams',
        rating: 5,
        text: 'A fascinating perspective on human history that challenges conventional thinking.',
        date: '2023-09-30T10:12:45Z'
      },
      {
        id: '402',
        userId: '4002',
        userName: 'Sarah Thompson',
        rating: 4,
        text: 'Thought-provoking and engaging from start to finish.',
        date: '2023-08-22T17:19:53Z'
      }
    ],
    language: 'English',
    pages: 443,
    publishDate: '2011-01-01',
    isbn: '9780062316097'
  },
  {
    id: '5',
    title: 'مدينة الله',
    author: 'أحمد خالد توفيق',
    cover: 'https://images.pexels.com/photos/4466381/pexels-photo-4466381.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    summary: 'رواية خيال علمي تدور أحداثها في مستقبل بعيد، حيث يُقسم الناس إلى طبقات اجتماعية داخل مدينة مغلقة.',
    category: 'خيال علمي',
    rating: 4.4,
    reviews: [
      {
        id: '501',
        userId: '5001',
        userName: 'أمينة خالد',
        rating: 5,
        text: 'رواية مثيرة للاهتمام وغنية بالأفكار الفلسفية والاجتماعية.',
        date: '2023-07-14T08:45:32Z'
      },
      {
        id: '502',
        userId: '5002',
        userName: 'عمر محمود',
        rating: 4,
        text: 'أسلوب سرد شيق يجعلك تتخيل المستقبل بطريقة مختلفة تمامًا.',
        date: '2023-06-18T19:22:40Z'
      }
    ],
    language: 'العربية',
    pages: 312,
    publishDate: '2008-01-01',
    isbn: '9789774275326'
  },
  {
    id: '6',
    title: 'To Kill a Mockingbird',
    author: 'Harper Lee',
    cover: 'https://images.pexels.com/photos/4968391/pexels-photo-4968391.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    summary: 'A novel that explores themes of racial prejudice and injustice in the American South during the 1930s.',
    category: 'Fiction',
    rating: 4.9,
    reviews: [
      {
        id: '601',
        userId: '6001',
        userName: 'Michael Brown',
        rating: 5,
        text: 'A timeless classic that remains as relevant today as when it was first published.',
        date: '2023-10-25T15:50:19Z'
      }
    ],
    language: 'English',
    pages: 281,
    publishDate: '1960-07-11',
    isbn: '9780061120084'
  },
  {
    id: '7',
    title: 'تاريخ الحضارة العربية',
    author: 'غوستاف لوبون',
    cover: 'https://images.pexels.com/photos/7034646/pexels-photo-7034646.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    summary: 'كتاب تاريخي يتناول تاريخ الحضارة العربية والإسلامية وإسهاماتها في تطور العلوم والفنون.',
    category: 'تاريخ',
    rating: 4.7,
    reviews: [
      {
        id: '701',
        userId: '7001',
        userName: 'سمير حسن',
        rating: 5,
        text: 'مرجع قيم وشامل عن الحضارة العربية وإنجازاتها.',
        date: '2023-09-10T11:15:28Z'
      },
      {
        id: '702',
        userId: '7002',
        userName: 'ليلى عبد الرحمن',
        rating: 4,
        text: 'كتاب مهم لكل من يهتم بالتاريخ الإسلامي وتأثيره العالمي.',
        date: '2023-08-05T14:20:47Z'
      }
    ],
    language: 'العربية',
    pages: 528,
    publishDate: '1884-01-01',
    isbn: '9789777681292'
  },
  {
    id: '8',
    title: 'A Brief History of Time',
    author: 'Stephen Hawking',
    cover: 'https://images.pexels.com/photos/1629236/pexels-photo-1629236.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    summary: 'A book that explores the nature of time, space, and the universe in terms accessible to non-scientists.',
    category: 'Science',
    rating: 4.5,
    reviews: [
      {
        id: '801',
        userId: '8001',
        userName: 'David Wilson',
        rating: 4,
        text: 'Hawking makes complex physics concepts understandable to the average reader.',
        date: '2023-11-02T09:30:22Z'
      },
      {
        id: '802',
        userId: '8002',
        userName: 'Jennifer Parker',
        rating: 5,
        text: 'A masterpiece that changed my perspective on the universe.',
        date: '2023-10-15T16:45:38Z'
      }
    ],
    language: 'English',
    pages: 212,
    publishDate: '1988-01-01',
    isbn: '9780553380163'
  }
];