// User related types
export interface User {
  id: string;
  email: string;
  fullName: string;
  avatar?: string;
}

// Book related types
export interface Review {
  id: string;
  userId: string;
  userName: string;
  rating: number;
  text: string;
  date: string;
}

export interface Book {
  id: string;
  title: string;
  author: string;
  cover: string;
  summary: string;
  category: string;
  rating: number;
  reviews: Review[];
  language: string;
  pages: number;
  publishDate: string;
  isbn: string;
}

// Translation related types
export interface TranslationDictionary {
  [key: string]: string;
}

export interface Translations {
  en: TranslationDictionary;
  ar: TranslationDictionary;
}