import React from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { BookX, Home } from 'lucide-react';

const NotFound: React.FC = () => {
  const { t, language } = useLanguage();
  
  return (
    <div className={`min-h-screen flex flex-col justify-center items-center bg-amber-50 dark:bg-gray-900 p-4 ${language === 'ar' ? 'font-arabic' : 'font-english'}`}>
      <div className="text-center max-w-md">
        <div className="flex justify-center mb-6">
          <div className="bg-amber-100 dark:bg-blue-900 p-6 rounded-full">
            <BookX className="h-16 w-16 text-amber-600 dark:text-blue-400" />
          </div>
        </div>
        
        <h1 className="text-6xl font-bold text-amber-600 dark:text-blue-500 mb-4">404</h1>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Page Not Found</h2>
        <p className="text-gray-600 dark:text-gray-400 mb-8">
          The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.
        </p>
        
        <Link 
          to="/"
          className="px-6 py-3 bg-amber-600 dark:bg-blue-600 text-white rounded-lg hover:bg-amber-700 dark:hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-amber-500 dark:focus:ring-blue-500 focus:ring-offset-2 inline-flex items-center"
        >
          <Home className="h-5 w-5 mr-2 rtl:ml-2 rtl:mr-0" />
          {t('nav.home')}
        </Link>
      </div>
    </div>
  );
};

export default NotFound;