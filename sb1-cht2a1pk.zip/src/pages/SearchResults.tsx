import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useBooks } from '../contexts/BookContext';
import { useLanguage } from '../contexts/LanguageContext';
import SearchBar from '../components/Search/SearchBar';
import BookGrid from '../components/Books/BookGrid';
import { Book } from '../types';

const SearchResults: React.FC = () => {
  const location = useLocation();
  const { searchBooks, loading } = useBooks();
  const { t } = useLanguage();
  
  const [results, setResults] = useState<Book[]>([]);
  const [query, setQuery] = useState('');
  
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const q = searchParams.get('q');
    const category = searchParams.get('category') || undefined;
    
    if (q) {
      setQuery(q);
      const searchResults = searchBooks(q, category);
      setResults(searchResults);
    }
  }, [location.search, searchBooks]);
  
  const handleSearch = (newQuery: string, category?: string) => {
    const searchResults = searchBooks(newQuery, category);
    setResults(searchResults);
    setQuery(newQuery);
    
    // Update URL without refreshing page
    const params = new URLSearchParams();
    params.set('q', newQuery);
    if (category) params.set('category', category);
    window.history.pushState({}, '', `${window.location.pathname}?${params.toString()}`);
  };
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin h-8 w-8 border-4 border-amber-500 dark:border-blue-500 border-t-transparent rounded-full"></div>
        <span className="ml-3 rtl:mr-3 rtl:ml-0 text-gray-700 dark:text-gray-300">{t('loading')}</span>
      </div>
    );
  }
  
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6 text-gray-900 dark:text-white">{t('search.results')}</h1>
      
      <SearchBar onSearch={handleSearch} initialQuery={query} />
      
      {results.length > 0 ? (
        <BookGrid books={results} />
      ) : (
        <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-md text-center">
          <p className="text-gray-600 dark:text-gray-300 text-lg mb-4">{t('search.noResults')}</p>
          <p className="text-gray-500 dark:text-gray-400">Try adjusting your search terms or browse by category.</p>
        </div>
      )}
    </div>
  );
};

export default SearchResults;