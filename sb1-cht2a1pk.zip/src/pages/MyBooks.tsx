import React from 'react';
import { useBooks } from '../contexts/BookContext';
import { useLanguage } from '../contexts/LanguageContext';
import BookGrid from '../components/Books/BookGrid';
import { Book } from 'lucide-react';

const MyBooks: React.FC = () => {
  const { myBooks, loading } = useBooks();
  const { t } = useLanguage();
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin h-8 w-8 border-4 border-amber-500 dark:border-blue-500 border-t-transparent rounded-full"></div>
        <span className="ml-3 rtl:mr-3 rtl:ml-0 text-gray-700 dark:text-gray-300">{t('loading')}</span>
      </div>
    );
  }
  
  if (myBooks.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16">
        <div className="bg-amber-100 dark:bg-blue-900 p-6 rounded-full mb-6">
          <Book className="h-16 w-16 text-amber-600 dark:text-blue-400" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">{t('myBooks.empty')}</h2>
        <p className="text-gray-600 dark:text-gray-400 mb-6 text-center">{t('myBooks.start')}</p>
        <a 
          href="/"
          className="px-4 py-2 bg-amber-600 dark:bg-blue-600 text-white rounded-lg hover:bg-amber-700 dark:hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-amber-500 dark:focus:ring-blue-500 focus:ring-offset-2"
        >
          {t('nav.home')}
        </a>
      </div>
    );
  }
  
  return (
    <div>
      <h1 className="text-3xl font-bold mb-8 text-gray-900 dark:text-white">{t('nav.myBooks')}</h1>
      <BookGrid books={myBooks} />
    </div>
  );
};

export default MyBooks;