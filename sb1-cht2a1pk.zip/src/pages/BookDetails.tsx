import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useBooks } from '../contexts/BookContext';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import StarRating from '../components/Books/StarRating';
import ReviewCard from '../components/Reviews/ReviewCard';
import ReviewForm from '../components/Reviews/ReviewForm';
import BookGrid from '../components/Books/BookGrid';
import { Book as BookIcon, Calendar, Languages, Hash, BookOpen, Heart, ArrowLeft } from 'lucide-react';

const BookDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { getBookById, addToMyBooks, removeFromMyBooks, myBooks, addReview, books } = useBooks();
  const { user } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  
  const [book, setBook] = useState<Book | undefined>(undefined);
  const [isInMyBooks, setIsInMyBooks] = useState(false);
  const [relatedBooks, setRelatedBooks] = useState<Book[]>([]);
  
  useEffect(() => {
    if (id) {
      const foundBook = getBookById(id);
      setBook(foundBook);
      
      // Check if book is in myBooks
      if (foundBook && myBooks.some(b => b.id === foundBook.id)) {
        setIsInMyBooks(true);
      } else {
        setIsInMyBooks(false);
      }
      
      // Get related books (same category)
      if (foundBook) {
        const related = books
          .filter(b => b.category === foundBook.category && b.id !== foundBook.id)
          .slice(0, 5);
        setRelatedBooks(related);
      }
    }
  }, [id, getBookById, myBooks, books]);
  
  const handleAddToMyBooks = () => {
    if (book) {
      addToMyBooks(book.id);
      setIsInMyBooks(true);
    }
  };
  
  const handleRemoveFromMyBooks = () => {
    if (book) {
      removeFromMyBooks(book.id);
      setIsInMyBooks(false);
    }
  };
  
  const handleReviewSubmit = (rating: number, text: string) => {
    if (book) {
      addReview(book.id, rating, text);
      // Refresh book data
      const updatedBook = getBookById(book.id);
      setBook(updatedBook);
    }
  };
  
  if (!book) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin h-8 w-8 border-4 border-amber-500 dark:border-blue-500 border-t-transparent rounded-full"></div>
        <span className="ml-3 rtl:mr-3 rtl:ml-0 text-gray-700 dark:text-gray-300">{t('loading')}</span>
      </div>
    );
  }
  
  return (
    <div>
      <button 
        onClick={() => navigate(-1)}
        className="mb-6 flex items-center text-amber-700 dark:text-blue-400 hover:underline"
      >
        <ArrowLeft className="h-4 w-4 mr-1 rtl:ml-1 rtl:mr-0" />
        Back
      </button>
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden mb-8">
        <div className="md:flex">
          {/* Book cover */}
          <div className="md:w-1/3 p-6">
            <div className="relative h-[400px] md:h-[500px] overflow-hidden rounded-lg shadow-md">
              <img 
                src={book.cover} 
                alt={book.title} 
                className="w-full h-full object-cover"
              />
            </div>
          </div>
          
          {/* Book details */}
          <div className="md:w-2/3 p-6">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">{book.title}</h1>
            <div className="flex items-center mb-4">
              <StarRating initialRating={book.rating} size="md" />
              <span className="ml-2 rtl:mr-2 rtl:ml-0 text-amber-600 dark:text-amber-400">{book.rating.toFixed(1)} ({book.reviews.length} {t('book.reviews')})</span>
            </div>
            
            <div className="flex items-center text-gray-700 dark:text-gray-300 mb-6">
              <BookIcon className="h-5 w-5 mr-2 rtl:ml-2 rtl:mr-0" />
              <span className="font-medium mr-1 rtl:ml-1 rtl:mr-0">{t('book.author')}:</span>
              <span>{book.author}</span>
            </div>
            
            <p className="text-gray-700 dark:text-gray-300 mb-6">{book.summary}</p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className="flex items-center text-gray-700 dark:text-gray-300">
                <BookOpen className="h-5 w-5 mr-2 rtl:ml-2 rtl:mr-0 text-amber-600 dark:text-blue-400" />
                <span className="font-medium mr-1 rtl:ml-1 rtl:mr-0">{t('book.pages')}:</span>
                <span>{book.pages}</span>
              </div>
              
              <div className="flex items-center text-gray-700 dark:text-gray-300">
                <Calendar className="h-5 w-5 mr-2 rtl:ml-2 rtl:mr-0 text-amber-600 dark:text-blue-400" />
                <span className="font-medium mr-1 rtl:ml-1 rtl:mr-0">{t('book.published')}:</span>
                <span>{book.publishDate}</span>
              </div>
              
              <div className="flex items-center text-gray-700 dark:text-gray-300">
                <Languages className="h-5 w-5 mr-2 rtl:ml-2 rtl:mr-0 text-amber-600 dark:text-blue-400" />
                <span className="font-medium mr-1 rtl:ml-1 rtl:mr-0">{t('book.language')}:</span>
                <span>{book.language}</span>
              </div>
              
              <div className="flex items-center text-gray-700 dark:text-gray-300">
                <Hash className="h-5 w-5 mr-2 rtl:ml-2 rtl:mr-0 text-amber-600 dark:text-blue-400" />
                <span className="font-medium mr-1 rtl:ml-1 rtl:mr-0">{t('book.isbn')}:</span>
                <span>{book.isbn}</span>
              </div>
            </div>
            
            {user ? (
              <div>
                {isInMyBooks ? (
                  <button 
                    onClick={handleRemoveFromMyBooks}
                    className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors focus:outline-none focus:ring-2 focus:ring-amber-500 dark:focus:ring-blue-500 focus:ring-offset-2 flex items-center"
                  >
                    <Heart className="h-5 w-5 mr-2 rtl:ml-2 rtl:mr-0 fill-red-500 text-red-500" />
                    {t('book.removeFromMyBooks')}
                  </button>
                ) : (
                  <button 
                    onClick={handleAddToMyBooks}
                    className="px-4 py-2 bg-amber-600 dark:bg-blue-600 text-white rounded-lg hover:bg-amber-700 dark:hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-amber-500 dark:focus:ring-blue-500 focus:ring-offset-2 flex items-center"
                  >
                    <Heart className="h-5 w-5 mr-2 rtl:ml-2 rtl:mr-0" />
                    {t('book.addToMyBooks')}
                  </button>
                )}
              </div>
            ) : null}
          </div>
        </div>
      </div>
      
      {/* Reviews section */}
      <div className="mb-12">
        <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">{t('book.reviews')}</h2>
        
        {user && (
          <ReviewForm onSubmit={handleReviewSubmit} />
        )}
        
        {book.reviews.length > 0 ? (
          <div>
            {book.reviews.map(review => (
              <ReviewCard key={review.id} review={review} />
            ))}
          </div>
        ) : (
          <p className="text-gray-600 dark:text-gray-400">No reviews yet. Be the first to review this book!</p>
        )}
      </div>
      
      {/* Related books */}
      {relatedBooks.length > 0 && (
        <BookGrid 
          books={relatedBooks} 
          title={t('book.relatedBooks')} 
        />
      )}
    </div>
  );
};

export default BookDetails;