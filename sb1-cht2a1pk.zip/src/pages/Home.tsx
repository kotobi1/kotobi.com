import React, { useState, useEffect } from 'react';
import { useBooks } from '../contexts/BookContext';
import { useLanguage } from '../contexts/LanguageContext';
import BookGrid from '../components/Books/BookGrid';
import { Book } from '../types';

const Home: React.FC = () => {
  const { books, loading, error } = useBooks();
  const { t } = useLanguage();
  const [categories, setCategories] = useState<string[]>([]);
  const [categorizedBooks, setCategorizedBooks] = useState<Record<string, Book[]>>({});
  
  // Extract unique categories and organize books by category
  useEffect(() => {
    if (books.length > 0) {
      const uniqueCategories = Array.from(new Set(books.map(book => book.category)));
      setCategories(uniqueCategories);
      
      const booksByCategory: Record<string, Book[]> = {};
      uniqueCategories.forEach(category => {
        booksByCategory[category] = books.filter(book => book.category === category);
      });
      
      setCategorizedBooks(booksByCategory);
    }
  }, [books]);
  
  // Get top rated books
  const topRatedBooks = [...books].sort((a, b) => b.rating - a.rating).slice(0, 5);
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin h-8 w-8 border-4 border-amber-500 dark:border-blue-500 border-t-transparent rounded-full"></div>
        <span className="ml-3 rtl:mr-3 rtl:ml-0 text-gray-700 dark:text-gray-300">{t('loading')}</span>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="bg-red-100 dark:bg-red-900 border border-red-400 dark:border-red-700 text-red-700 dark:text-red-200 px-4 py-3 rounded-md">
        <p>{error}</p>
      </div>
    );
  }
  
  return (
    <div>
      {/* Hero section */}
      <div className="relative h-[500px] mb-12 rounded-xl overflow-hidden">
        <img 
          src="https://images.pexels.com/photos/1370295/pexels-photo-1370295.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
          alt="Library of books" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-amber-900/80 to-transparent flex items-center">
          <div className="px-8 md:px-16 max-w-2xl">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">BookVerse</h1>
            <p className="text-xl text-amber-100 mb-8">Discover, read, and share your thoughts on thousands of books across multiple genres and languages.</p>
            <button className="px-6 py-3 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors focus:outline-none focus:ring-2 focus:ring-amber-500 focus:ring-offset-2">
              Explore Books
            </button>
          </div>
        </div>
      </div>
      
      {/* Top rated books */}
      <BookGrid 
        books={topRatedBooks} 
        title="Top Rated Books" 
      />
      
      {/* Books by category */}
      {categories.map(category => (
        <BookGrid
          key={category}
          books={categorizedBooks[category]}
          title={category}
        />
      ))}
    </div>
  );
};

export default Home;