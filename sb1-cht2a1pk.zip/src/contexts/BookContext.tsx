import React, { createContext, useState, useContext, useEffect } from 'react';
import { Book, Review } from '../types';
import { mockBooks } from '../data/mockBooks';

interface BookContextType {
  books: Book[];
  myBooks: Book[];
  loading: boolean;
  error: string | null;
  addToMyBooks: (bookId: string) => void;
  removeFromMyBooks: (bookId: string) => void;
  addReview: (bookId: string, rating: number, text: string) => void;
  getBookById: (id: string) => Book | undefined;
  searchBooks: (query: string, category?: string) => Book[];
  getBooksByCategory: (category: string) => Book[];
}

const BookContext = createContext<BookContextType | null>(null);

export const useBooks = () => {
  const context = useContext(BookContext);
  if (!context) {
    throw new Error('useBooks must be used within a BookProvider');
  }
  return context;
};

export const BookProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [books, setBooks] = useState<Book[]>([]);
  const [myBooks, setMyBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load mock data on mount
  useEffect(() => {
    try {
      setLoading(true);
      // Load books from mock data
      setBooks(mockBooks);
      
      // Check for stored myBooks
      const storedMyBooks = localStorage.getItem('myBooks');
      if (storedMyBooks) {
        const myBookIds = JSON.parse(storedMyBooks) as string[];
        const myBooksData = mockBooks.filter(book => myBookIds.includes(book.id));
        setMyBooks(myBooksData);
      }
    } catch (err) {
      setError('Failed to load books data.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  const addToMyBooks = (bookId: string) => {
    const book = books.find(b => b.id === bookId);
    if (book && !myBooks.some(b => b.id === bookId)) {
      const updatedMyBooks = [...myBooks, book];
      setMyBooks(updatedMyBooks);
      // Store my books IDs in localStorage
      localStorage.setItem('myBooks', JSON.stringify(updatedMyBooks.map(b => b.id)));
    }
  };

  const removeFromMyBooks = (bookId: string) => {
    const updatedMyBooks = myBooks.filter(book => book.id !== bookId);
    setMyBooks(updatedMyBooks);
    // Update localStorage
    localStorage.setItem('myBooks', JSON.stringify(updatedMyBooks.map(b => b.id)));
  };

  const addReview = (bookId: string, rating: number, text: string) => {
    // Create new review
    const newReview: Review = {
      id: Date.now().toString(),
      userId: '1', // Mock user ID
      rating,
      text,
      date: new Date().toISOString(),
      userName: 'Current User' // Mock user name
    };

    // Update books with new review
    const updatedBooks = books.map(book => {
      if (book.id === bookId) {
        // Calculate new average rating
        const totalRatings = book.reviews.length + 1;
        const sumRatings = book.reviews.reduce((sum, review) => sum + review.rating, 0) + rating;
        const newAverageRating = sumRatings / totalRatings;
        
        return {
          ...book,
          reviews: [...book.reviews, newReview],
          rating: newAverageRating
        };
      }
      return book;
    });

    setBooks(updatedBooks);

    // Update myBooks if the reviewed book is in myBooks
    if (myBooks.some(book => book.id === bookId)) {
      const updatedMyBooks = myBooks.map(book => {
        if (book.id === bookId) {
          // Calculate new average rating
          const totalRatings = book.reviews.length + 1;
          const sumRatings = book.reviews.reduce((sum, review) => sum + review.rating, 0) + rating;
          const newAverageRating = sumRatings / totalRatings;
          
          return {
            ...book,
            reviews: [...book.reviews, newReview],
            rating: newAverageRating
          };
        }
        return book;
      });

      setMyBooks(updatedMyBooks);
    }
  };

  const getBookById = (id: string) => {
    return books.find(book => book.id === id);
  };

  const searchBooks = (query: string, category?: string) => {
    const lowercaseQuery = query.toLowerCase();
    
    return books.filter(book => {
      const matchesQuery = 
        book.title.toLowerCase().includes(lowercaseQuery) || 
        book.author.toLowerCase().includes(lowercaseQuery);
      
      if (category) {
        return matchesQuery && book.category === category;
      }
      
      return matchesQuery;
    });
  };

  const getBooksByCategory = (category: string) => {
    return books.filter(book => book.category === category);
  };

  const value = {
    books,
    myBooks,
    loading,
    error,
    addToMyBooks,
    removeFromMyBooks,
    addReview,
    getBookById,
    searchBooks,
    getBooksByCategory
  };

  return <BookContext.Provider value={value}>{children}</BookContext.Provider>;
};